chrome.cookies.getAll({ domain: "instagram.com" }, (cookies) => {
  let cookieContainer = document.getElementById("cookie-container");
  let allCookiesText = "";

  cookies.forEach(cookie => {
    let cookieText = `${cookie.name}=${cookie.value}; `;
    allCookiesText += cookieText;
    let span = document.createElement("span");
    span.textContent = cookieText;
    cookieContainer.appendChild(span);
  });

  document.getElementById("copy-all").addEventListener("click", () => {
    navigator.clipboard.writeText(allCookiesText).then(() => {
      alert("Cookies telah disalin!");
    }).catch(err => {
      alert("Gagal menyalin cookies: " + err);
    });
  });
});
