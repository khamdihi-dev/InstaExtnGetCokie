chrome.runtime.onInstalled.addListener(() => {
    console.log("Khamdihi-dev");
  });
  
  chrome.cookies.getAll({domain: "instagram.com"}, (cookies) => {
    console.log(cookies);
  });
  